
// Disable auto updates
user_pref("app.update.auto", false);

// Disalbe the security warning due to http
user_pref("security.insecure_field_warning.contextual.enabled", false);

// Disalbe data reporting to Mozilla
user_pref("datareporting.healthreport.uploadEnabled", false);
user_pref("app.shield.optoutstudies.enabled", false);
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false);

