#!/bin/bash

#modified seed script

echo "Configuring the system ..."
sudo cp /home/seed/.gdbinit ~/.gdbinit

#-------------------------------------------------------------
# Copy the .bashrc file
cp ./seed_bashrc ~/.bashrc

#-------------------------------------------------------------
# Set up the background image
sudo cp ./seed-vm-background-tesla-coil.jpg /usr/share/backgrounds/
sudo cp ./seed-wallpapers.xml /usr/share/gnome-background-properties/

#------------------------------------------------------------------
# Copy user-account profile

cp ./config_user ~/.config/dconf/user

# Note 1: copying this file is not always working. The file will be
#         changed back by the system. So, after copying, log out immediately,
#         and then log in again. This will work

# Note 2: if we have copied the "user" file to ~/.config/dconf,
#         we don't need to run the following commands.

# First time, after configuring Gnome-Terminal, save the setting
# dconf dump /org/gnome/terminal/ > gnome_terminal_settings.txt

# Load the prestored setting
# dconf load /org/gnome/terminal/ < gnome_terminal_settings.txt

#------------------------------------------------
# Copy system files
#sudo cp $FileDir/etc_sudoers  /etc/sudoers
sudo cp ./etc_hosts /etc/hosts
# Disable the "internal error" message
sudo cp ./etc_default_apport /etc/default/apport

echo "Everything is done please log out then log in back to this account"
